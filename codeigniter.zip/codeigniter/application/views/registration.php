<?php
include "header.php";
?>
<div id="subheader">
    <div class="row">
        <div class="twelve columns">
            <p class="left">
                REGISTRATION
            </p>
            <p class="right">
                Register today
            </p>
        </div>
    </div>
</div>
<div class="hr">
</div>
<!-- CONTENT 
================================================== -->

<div class="row">
    
    <div class="twelve columns">
        <div class="wrapcontact">
    
	<form enctype="multipart/form-data" method="POST" action="<?php echo base_url("index.php/Welcome/add_registration_action"); ?>">
		<div class="six columns noleftmargin">
                        <label>Name</label>
                        <input type="text" name="name" class="smoothborder" placeholder="Your name *" />
                    </div>
                    <div class="six columns">
                        <label>E-mail address</label>
                        <input type="text" name="email" class="smoothborder" placeholder="Your e-mail address *" />
                    </div>
                    <div class="six columns noleftmargin">
                        <label>Password</label>
                        <input type="password" name="pass" class="smoothborder" placeholder="password *" />
                    </div>
                    <div class="six columns">
                        <label>Phone no</label>
                        <input type="text" name="phone" class="smoothborder" placeholder="Your phone no *" />
                    </div>
                    <div class="six columns noleftmargin">
                        <label>City</label>
                        <input type="text" name="city" class="smoothborder" placeholder="Your city *" />
                    </div>
                    <div class="six columns ">
                        <label>Photo</label>
                        <input type="file" name="photo" class="smoothborder" placeholder="Photo *" />
                    </div>
                    
                    <div class="twelve columns noleftmargin">
                        <label>Address</label>
                        <textarea name="address" class="smoothborder ctextarea" rows="14" placeholder="Your Address *"></textarea>
                        <input type="submit" name="submit" id="submit" class="readmore" value="Submit">
                    </div>
	   </form>
    </div>
    </div>
</div>
<?php
include "footer.php";
?>