<!DOCTYPE html>
<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->
<head>
<meta charset="utf-8"/>
<!-- Set the viewport width to device width for mobile -->
<meta name="viewport" content="width=device-width"/>
<title>Studio Francesca - Premium Theme by WowThemesNet</title>
<!-- CSS Files-->
<link rel="stylesheet" href="<?php echo base_url(); ?>stylesheets/style.css">

<link rel="stylesheet" href="<?php echo base_url(); ?>stylesheets/skins/blue.css">
<!-- skin color -->
<link rel="stylesheet" href="<?php echo base_url(); ?>stylesheets/responsive.css">
<!-- IE Fix for HTML5 Tags -->
<!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
</head>
<body>
<!-- HIDDEN PANEL 
================================================== -->
<div id="panel">
	<div class="row">
		<div class="twelve columns">
			<img src="http://www.wowthemes.net/demo/studiofrancesca/images/info.png" class="pics" alt="info">
			<div class="infotext">
				 Thank you for visiting my theme! Replace this with your message to visitors.
			</div>
		</div>
	</div>
</div>
<p class="slide">
	<a href="#" class="btn-slide"></a>
</p>
<!-- HEADER
================================================== -->
<div class="row">
	<div class="headerlogo four columns">
		<div class="logo">
			<a href="<?php echo base_url()?>index.php/Welcome/home">
			<h4>My Diary</h4>
			</a>
		</div>
	</div>
	<div class="headermenu eight columns noleftmarg">
		<nav id="nav-wrap">
		<ul id="main-menu" class="nav-bar sf-menu">
			<li class="current">
			<a href="<?php echo base_url()?>index.php/Welcome/home">Home</a>
				
			</li>
			<li>
			<a href="#">About Us</a>
					
			</li>
			<li>
			<a href="<?php echo base_url()?>index.php/Welcome/registration">Registration</a>
			
			</li>
			<li>
			<a href="<?php echo base_url()?>index.php/Welcome/login">Login</a>
			
			</li>
			<li>
			<a href="<?php echo base_url()?>index.php/Welcome/enquiry">Contact us</a>
			
			</li>

		</ul>
		</nav>
	</div>
</div>
<div class="clear">
</div>