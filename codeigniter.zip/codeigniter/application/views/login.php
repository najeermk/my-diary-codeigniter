<?php
include "header.php";
?>
<div id="subheader">
    <div class="row">
        <div class="twelve columns">
            <p class="left">
                LOGIN
            </p>
            <p class="right">
                
            </p>
        </div>
    </div>
</div>
<div class="hr">
</div>
<!-- CONTENT 
================================================== -->

<div class="row">
    
    <div class="twelve columns">
        <div class="wrapcontact">
	<form method="POST" action="<?php echo base_url("index.php/Welcome/login_action"); ?>">
		<div>
			<label>Email</label>
			<input type="email" name="email" class="smoothborder">
		</div>
		<div>
			<label>Password</label>
			<input type="password" name="pass" class="smoothborder">
		</div>
		<div>
			<input type="submit" name="submit" value="login">
		</div>
		
		
	</form>
</div>
</div>
</div>

<?php
include "footer.php";
?>