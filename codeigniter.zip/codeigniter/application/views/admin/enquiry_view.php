<?php
include "header.php";
?>

<div class="row">
    
    <div class="twelve columns">
        <div class="wrapcontact">
<table width="100%">
<tr>
	<th>Name</th>
	<th>Email</th>
	<th>Message</th>
</tr>

<?php
 foreach($data as $val)
 {
 ?>
<tr>
	<td><?php echo $val["name"]; ?></td>
    <td><?php echo $val["email"]; ?></td>
    <td><?php echo $val["message"]; ?></td>
</tr>

<?php

}
?>
</table>
</div>
</div>
</div>


<?php
include "footer.php";
?>