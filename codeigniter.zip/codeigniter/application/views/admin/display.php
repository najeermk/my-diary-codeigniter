<?php
include "header.php";
?>

<div class="row">
    
    <div class="twelve columns">
        <div class="wrapcontact">
<table width="100%">
<tr>
	<th>Name</th>
	<th>Email</th>
	<th>Password</th>
	<th>Phone</th>
	<th>City</th>
	<th>Photo</th>
	<th>Address</th>
</tr>

<?php
 foreach($data as $val)
 {
 ?>
<tr>
	<td><?php echo $val["name"]; ?></td>
    <td><?php echo $val["email"]; ?></td>
    <td><?php echo $val["userid"]; ?></td>
    <td><?php echo $val["phoneno"]; ?></td>
    <td><?php echo $val["city"]; ?></td>
    <td><img src="<?php echo base_url('./uploads/')?><?php echo  $val['photo']?>" width="100px"></td>
    <td><?php echo $val["address"]; ?></td>
 </tr>
 <?php
 }
 ?>
</table>
</div>
</div>
</div>

<?php
include "footer.php";
?>