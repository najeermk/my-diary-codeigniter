
<?php
include "header.php";
?>

<div id="subheader">
	<div class="row">
		<div class="twelve columns">
			<p class="left">
				 CONTACT US
			</p>
			<p class="right">
				 Get in touch today!
			</p>
		</div>
	</div>
</div>
<div class="hr">
</div>

<div class="row">
	<!-- CONTACT FORM -->
	<div class="twelve columns">
		<div class="wrapcontact">
			<h5>SEND US A MESSAGE</h5>
			<div class="done">
				<div class="alert-box success">
				 Message has been sent! <a href="" class="close">x</a>
				</div>
			</div>			
				<form method="post" action="<?php echo base_url("index.php/Welcome/enquiry_action"); ?>" id="contactform">
				<div class="form">
				    <div class="six columns noleftmargin">
					<label>Name</label>
					<input type="text" name="name" class="smoothborder" placeholder="Your name *"/>
					</div>
					<div class="six columns">
					<label>E-mail address</label>
					<input type="text" name="email" class="smoothborder" placeholder="Your e-mail address *"/>
					</div>
					<label>Message</label>
					<textarea name="comment" class="smoothborder ctextarea" rows="14" placeholder="Message, feedback, comments *"></textarea>
					<input type="submit" id="submit" class="readmore" value="Submit">
				</div>
				</form>			
		</div>
	</div>
												
</div>

<?php



include "footer.php";
?>