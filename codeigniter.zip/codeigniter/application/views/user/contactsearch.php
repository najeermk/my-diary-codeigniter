<?php
include "header.php";
?>
<div class="row">
    
    <div class="twelve columns">
        <div class="wrapcontact">

	<form method="POST" action="<?php echo base_url("index.php/Welcome/contact_search_action"); ?>">
		<label>Id</label>
		<input type="text" name="searchbar" class="smoothborder">
		<input type="submit" name="search" value="search">
	</form>
</div>
</div>
</div>
<?php
include "footer.php";
?>