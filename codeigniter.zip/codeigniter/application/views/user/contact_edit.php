<?php
include "header.php";
?>

<div class="row">
    
    <div class="twelve columns">
        <div class="wrapcontact">
<table width="100%">
<tr>
	<th>Id</th>
	<th>Name</th>
	<th>Email</th>
	<th>City</th>
	<th>Date of Birth</th>
	<th>Phone no1</th>
	<th>Phone no2</th>
	<th>Address</th>
</tr>
<form method="POST" action="<?php echo base_url("index.php/Welcome/contact_edit_action"); ?>">
<?php
 foreach($data as $val)
 {
 ?>
<tr>
	<td><input type="text" name="id" value="<?php echo $val['id']; ?>" readonly></td>
	<td><input type="text" value="<?php echo $val['name']; ?>" name="name"></td>
	<td><input type="text" value="<?php echo $val['email']; ?>" name="email"></td>
	<td><input type="text" value="<?php echo $val['city']; ?>" name="city"></td>
	<td><input type="text" value="<?php echo $val['dateofbirth']; ?>" name="dateofbirth"></td>
	<td><input type="text" value="<?php echo $val['phoneno1']; ?>" name="phoneno1"></td>
	<td><input type="text" value="<?php echo $val['phoneno2']; ?>" name="phoneno2"></td>
	<td><input type="text" value="<?php echo $val['address']; ?>" name="address"></td>
	<td><input type="submit" name="update" value="update"></td>
 </tr>

 <?php
 }



 ?>
 </form>
</table>
</div>
</div>
</div>

<?php
include "footer.php";
?>