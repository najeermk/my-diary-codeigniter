<?php
include "header.php";
?>

 <div id="subheader">
    <div class="row">
        <div class="twelve columns">
            <p class="left">
                CONTACTS
            </p>
            <p class="right">
                
            </p>
        </div>
    </div>
</div>
<div class="hr">
</div>
<!-- CONTENT 
================================================== -->

<div class="row">
    <!-- CONTACT FORM -->
    <div class="twelve columns">
        <div class="wrapcontact">

 <form method="post" action="<?php echo base_url("index.php/Welcome/add_contacts_action"); ?>" id="contactform">
                <div class="form">
                    <div class="six columns noleftmargin">
                        <label>Name</label>
                        <input type="text" name="name" class="smoothborder" placeholder="Your name *" />
                    </div>
                    <div class="six columns">
                        <label>E-mail address</label>
                        <input type="text" name="email" class="smoothborder" placeholder="Your e-mail address *" />
                    </div>
                    <div class="six columns noleftmargin">
                        <label>city</label>
                        <input type="text" name="city" class="smoothborder" placeholder="Your name *" />
                    </div>
                    <div class="six columns ">
                        <label>Date of birth</label>
                        <input type="date" name="date" class="smoothborder" placeholder="Your name *" />
                    </div>
                    <div class="six columns noleftmargin">
                        <label>Phone no 1</label>
                        <input type="text" name="phone1" class="smoothborder" placeholder="Your name *" />
                    </div>
                    <div class="six columns ">
                        <label>Phone no 2</label>
                        <input type="text" name="phone2" class="smoothborder" placeholder="Your name *" />
                    </div>
                    <label>Address</label>
                    <textarea name="address" class="smoothborder ctextarea" rows="14" placeholder="Address"></textarea>
                    <input type="submit" id="submit" name="submit" class="readmore" value="Submit">
                </div>
            </form>
        </div>
    </div>
</div>

<?php
include "footer.php";
?>
