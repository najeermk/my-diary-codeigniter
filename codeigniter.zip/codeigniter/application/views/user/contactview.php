<?php
include "header.php";
?>

<div class="row">
    
    <div class="twelve columns">
        <div class="wrapcontact">
<table width="100%">
<tr>
	<th>Id</th>
	<th>Name</th>
	<th>Email</th>
	<th>City</th>
	<th>Date of Birth</th>
	<th>Phone no1</th>
	<th>Phone no2</th>
	<th>Address</th>
</tr>

<?php
 foreach($data as $val)
 {
 ?>
<tr>
	<td><?php echo $val["id"]; ?></td>
	<td><?php echo $val["name"]; ?></td>
    <td><?php echo $val["email"]; ?></td>
    <td><?php echo $val["city"]; ?></td>
    <td><?php echo $val["dateofbirth"]; ?></td>
    <td><?php echo $val["phoneno1"]; ?></td>
    <td><?php echo $val["phoneno2"]; ?></td>
    <td><?php echo $val["address"]; ?></td>
 </tr>
 <?php
 }
 ?>
</table>
</div>
</div>
</div>
<?php
include "footer.php";
?>