<?php
include "header.php";
?>


	<table width="100%">
		<tr>
			<td><a href="<?php echo base_url()?>index.php/Welcome/registration">Registration</a></td>
			<td><a href="<?php echo base_url()?>index.php/Welcome/login">Login</a></td>
			<td><a href="<?php echo base_url()?>index.php/Welcome/contacts">Contacts</a></td>
			<td><a href="<?php echo base_url()?>index.php/Welcome/contactsearch">Contact Search</a></td>
			<td><a href="<?php echo base_url()?>index.php/Welcome/search">User Search</a></td>
			<td><a href="<?php echo base_url()?>index.php/Welcome/view">User View</a></td>
			<td><a href="<?php echo base_url()?>index.php/Welcome/contactview">Contact View</a></td>
		</tr>
	</table>
<?php
include "footer.php";
?>