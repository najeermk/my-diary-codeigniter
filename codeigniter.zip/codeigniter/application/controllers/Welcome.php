<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function registration()
	{
		$this->load->view('registration');
	}

	public function login()
	{
		$this->load->view('login');
	}

	public function contacts()
	{
		
		$this->load->view('/user/contacts');
	}
	public function add_registration_action()
	{
	$name=$this->input->post('name');
	$email=$this->input->post('email');
	$pass=$this->input->post('pass');
	$phone=$this->input->post('phone');
	$city=$this->input->post('city');
	$address=$this->input->post('address');

		$config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 1000000;
        $config['max_width']            = 102400;
        $config['max_height']           = 76800;
        $this->load->library('upload', $config);

         if (  $this->upload->do_upload('photo'))
        {
		$data = array('upload_data' => $this->upload->data());
     	$image=$data['upload_data']['file_name'];
     	}	
     	
	$data=array("name"=>$name,"email"=>$email,"phoneno"=>$phone,"city"=>$city,"photo"=>$image,"address"=>$address);

	$res=$this->DiaryModel->insert_all($data,"registration");

	$data2=array("email"=>$email, "password"=>$pass, "usertype"=>"user");
	$res2=$this->DiaryModel->insert_all($data2,"login");

	}

	public function display()
	{
	$data["data"]=$this->DiaryModel->get_data("registration");
	$this->load->view("admin/display",$data);
	}
	public function search()
	{
		$this->load->view("search");
	}
	public function search_action()
	{
		$userid=$this->input->post("searchbar");
		$data=array("userid"=>$userid);
		$data["data"]=$this->DiaryModel->get_where_data("registration",$data);	
		$this->load->view("display",$data);	
	}

	public function add_contacts_action()
	{
	$name=$this->input->post('name');
	$email=$this->input->post('email');
	$city=$this->input->post('city');
	$date=$this->input->post('date');
	$phone1=$this->input->post('phone1');
	$phone2=$this->input->post('phone2');
	$address=$this->input->post('address');
	$id=$_SESSION['id'];
	print($id);

	$data=array("name"=>$name,"email"=>$email,"city"=>$city,"dateofbirth"=>$date,"phoneno1"=>$phone1,"phoneno2"=>$phone2,"address"=>$address, "userid"=>$id);
	$res=$this->DiaryModel->insert_all($data,"contacts");
	}
	public function contactview()
	{
	
	$id=$_SESSION['id'];
	print($id);
	$data=array("userid"=>$id);
	$data["data"]=$this->DiaryModel->get_where_data("contacts",$data);
	$this->load->view("user/contactview",$data);
	}
	public function contactsearch()
	{
		$this->load->view("user/contactsearch");
	}
	public function contact_search_action()
	{
		$id=$this->input->post("searchbar");
		$data=array("id"=>$id);
		$data["data"]=$this->DiaryModel->get_where_data("contacts",$data);	
		$this->load->view("user/contact_edit",$data);	
	}
	public function contact_edit_action()
	{
	$id=$this->input->post('id');
	$name=$this->input->post('name');
	$email=$this->input->post('email');
	$city=$this->input->post('city');
	$date=$this->input->post('dateofbirth');
	$phone1=$this->input->post('phoneno1');
	$phone2=$this->input->post('phoneno2');
	$address=$this->input->post('address');
	

	$data=array("name"=>$name,"email"=>$email,"city"=>$city,"dateofbirth"=>$date,"phoneno1"=>$phone1,"phoneno2"=>$phone2,"address"=>$address);
	$where=array("id"=>$id);
	$this->DiaryModel->update_data("contacts",$data,$where);
	redirect(base_url('index.php/Welcome/user/contactview'));
	}
	public function menu()
	{
		$this->load->view("menu");
	}

	public function home()
	{
		$this->load->view("home");
	}
	public function enquiry()
	{
		$this->load->view("enquiry");
	}
	public function enquiry_action()
	{
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$message=$this->input->post('comment');

		$data = array('name' => $name, 'email'=>$email, 'message'=>$message);
		$res=$this->DiaryModel->insert_all($data,"enquiry");
		redirect(base_url('index.php/Welcome/enquiry'));
	}
	public function enquiry_view()
	{
		$data["data"]=$this->DiaryModel->get_data("enquiry");
		$this->load->view("enquiry_view",$data);
	}
	public function login_action()
	{
	
	$email=$this->input->post('email');
	$pass=$this->input->post('pass');
	$data=array("email"=>$email, "password"=>$pass);
	
	
 	$res=$this->DiaryModel->login_where("login",$data);
 	if($res==false)
		{
			$data["d1"]=array("msg"=>"Failed");
			$this->load->view("login",$data);
			
		}
	else
		{
			$_SESSION['id']=$res[0]['id'];
			
			if($res[0]["usertype"]== "admin"){
				redirect(base_url('index.php/Welcome/display'));
			}
			else{
				redirect(base_url('index.php/Welcome/contactview'));
			}

			
			
			

		}

	}
	function logout()
{
    $user_data = $this->session->all_userdata();
        foreach ($user_data as $key => $value) {
            if ($key != 'session_id' && $key != 'ip_address' && $key != 'user_agent' && $key != 'last_activity') {
                $this->session->unset_userdata($key);
            }
        }
    $this->session->sess_destroy();
    redirect('Welcome/login');
}
}

?>
