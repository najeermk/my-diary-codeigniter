<?php
class DiaryModel extends CI_Model
{
	
	function insert_all($data,$table)
	{
		$res=$this->db->insert($table,$data);
		if($res)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	function get_data($table)
	{
		$res=$this->db->get($table);
		return $res->result_array();
	}
	function get_where_data($table,$where)
	{
		$res=$this->db->get_where($table,$where);
		return $res->result_array();
	}
	function update_set($table,$data,$id)
	{
		$this->db->set('id', $data);
		$data=array("id"=>$id);
		$this->db->where($data);
		$this->db->update($table);

	}
	function update_data($table,$data,$where)
	{
		$this->db->set($data);
		$this->db->where($where);
		$this->db->update($table);

	}

	function login_where($table,$data)
	{
		$res=$this->db->get_where($table,$data);
		if($res->num_rows()>0)
		{
			return $res->result_array();
		}
		else
		{
			return false;
		}
	}
}	

?>