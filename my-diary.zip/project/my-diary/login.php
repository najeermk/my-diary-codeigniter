<?php

include "header.php";
?>
<div class="clear">
</div>


<div class="row">
    <div class="twelve columns">
        <div class="wrapcontact">
            <form method="post" action="#" id="contactform">
                <div class="form">

                    <div class="twelve columns noleftmargin">
                        <label>E-mail address</label>
                        <input type="text" name="email" class="smoothborder" placeholder="Your e-mail address *" />
                    </div>
                    <div class="twelve columns noleftmargin">
                        <label>Password</label>
                        <input type="password" name="password" class="smoothborder" placeholder="password *" />
                    </div>
                    <div>
                        <input type="submit" name="submit" id="submit" class="readmore" value="Submit">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<br><br><br><br>
<br><br><br><br>
<div class="hr"></div>
<?php


include "database.php";

if (isset($_POST["submit"])) {
    $email=$_POST["email"];
    $pass=$_POST["password"];
    $sql= "select * from login where email='$email' and password='$pass'";
    echo $sql;
    $result=mysqli_query($con, $sql);
    if ($row=mysqli_fetch_array($result)) {
        $usertype= $row["usertype"];
        $_SESSION["id"]=$row["id"];
        echo $_SESSION["id"];
        $_SESSION["email"]=$email;
        if ($usertype== "admin") {
            header("location:admin/registerview.php");
        }
        if ($usertype=="user") {
            header("location:user/contactview.php");
        }
    }
    else{
        echo "invalid email or password";
    }
}


include "footer.php";
?>