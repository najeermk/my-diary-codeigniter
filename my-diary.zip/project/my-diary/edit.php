<?php
include "header.php";
?>
<div class="clear">
</div>


<?php
include "database.php";

$id = $_GET["id"];
$sql = "select * from contacts where id=$id";
$result = mysqli_query($con, $sql);
while ($row = mysqli_fetch_array($result)) {
?>
    <form method="POST">
        <input readonly type="text" name="id" value='<?php echo $row["id"]; ?>'>
        <input type="text" name="name" value='<?php echo $row["name"]; ?>'>
        <input type="text" name="address" value='<?php echo $row["address"]; ?>'>
        <input type="text" name="city" value='<?php echo $row["city"]; ?>'>
        <input type="text" name="email" value='<?php echo $row["email"]; ?>'>
        <input type="text" name="phone1" value='<?php echo $row["phoneno1"]; ?>'>
        <input type="text" name="phone2" value='<?php echo $row["phoneno2"]; ?>'>
        <input type="submit" name="update" value="update">
    </form>

<?php
}

if (isset($_POST["update"])) {
    $id=$_POST["id"];
    $name=$_POST["name"];
    $address=$_POST["address"];
    $city=$_POST["city"];
    $email=$_POST["email"];
    $phoneno1=$_POST["phone1"];
    $phoneno2=$_POST["phone2"];
    $sql= "update contacts set name='$name', address='$address', city='$city', email='$email', phoneno1='$phoneno1', phoneno2='$phoneno2' where id='$id'";
    $result=mysqli_query($con, $sql);
    echo "updated";
    header("location:contactview.php");
}

include "footer.php";
?>