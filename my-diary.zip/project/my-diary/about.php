<?php
include "header.php";
?>

<div class="clear">
</div>
<!-- SUBHEADER
================================================== -->
<div id="subheader">
    <div class="row">
        <div class="twelve columns">
            <p class="left">
                ABOUT US
            </p>
            
        </div>
    </div>
</div>
<div class="hr">
</div>
<!-- CONTENT 
================================================== -->
<div class="row">
    <!-- MAIN CONTENT-->
    <div class="twelve columns">
        <!-- Our History-->
        <div class="sectiontitle">
            <h4>Our History</h4>
        </div>
        <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et rerum eveniet commodi odit soluta, eius ipsum veniam in iste? Voluptates ea facere itaque exercitationem ad cumque commodi repudiandae harum libero! Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro, itaque in maxime nam voluptatibus consequatur voluptatem autem impedit voluptatum distinctio eaque, aut incidunt! Dolorum voluptates commodi, animi aut accusamus nam. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Officia, rem tempora. Fugit eos, aliquam nam perspiciatis quis odio autem minus adipisci debitis blanditiis reprehenderit fuga error et beatae tempore labore. 
 
        </p>
    </div><!-- end main content-->

   
</div>
<div class="hr">
</div>

<?php
include "footer.php";
?>