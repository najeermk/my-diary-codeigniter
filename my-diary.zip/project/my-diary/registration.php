<?php
include "header.php";
?>
<div class="clear">
</div>
<!-- SUBHEADER
================================================== -->
<div id="subheader">
    <div class="row">
        <div class="twelve columns">
            <p class="left">
                REGISTRATION
            </p>
            <p class="right">
                Register today
            </p>
        </div>
    </div>
</div>
<div class="hr">
</div>
<!-- CONTENT 
================================================== -->

<div class="row">
    <!-- CONTACT FORM -->
    <div class="twelve columns">
        <div class="wrapcontact">
            <!-- <h5>SEND US A MESSAGE</h5>
                <div class="done">
                    <div class="alert-box success">
                        Message has been sent! <a href="" class="close">x</a>
                    </div>
                </div> -->
            <form method="post" action="#" id="contactform" enctype="multipart/form-data">
                <div class="form">
                    <div class="six columns noleftmargin">
                        <label>Name</label>
                        <input type="text" name="name" class="smoothborder" placeholder="Your name *" />
                    </div>
                    <div class="six columns">
                        <label>E-mail address</label>
                        <input type="text" name="email" class="smoothborder" placeholder="Your e-mail address *" />
                    </div>
                    <div class="six columns noleftmargin">
                        <label>Password</label>
                        <input type="password" name="pass" class="smoothborder" placeholder="password *" />
                    </div>
                    <div class="six columns">
                        <label>Phone no</label>
                        <input type="text" name="phone" class="smoothborder" placeholder="Your phone no *" />
                    </div>
                    <div class="six columns noleftmargin">
                        <label>City</label>
                        <input type="text" name="city" class="smoothborder" placeholder="Your city *" />
                    </div>
                    <div class="six columns ">
                        <label>Photo</label>
                        <input type="file" name="photo" class="smoothborder" placeholder="Photo *" />
                    </div>
                    
                    <div class="twelve columns noleftmargin">
                        <label>Address</label>
                        <textarea name="address" class="smoothborder ctextarea" rows="14" placeholder="Your Address *"></textarea>
                        <input type="submit" name="submit" id="submit" class="readmore" value="Submit">
                    </div>
                </div>
            </form>
        </div>
    </div>

</div>
<div class="hr">
</div>

<?php

include "database.php";

if (isset($_POST["submit"])) {
    $name = $_POST["name"];
    $email = $_POST["email"];
    
    $phoneno = $_POST["phone"];
    $city = $_POST["city"];
    $password = $_POST["pass"];
    $address = $_POST["address"];

    $filename = $_FILES["photo"]["name"];
    $file_loc = $_FILES["photo"]["tmp_name"];
    move_uploaded_file($file_loc, "upload/" . $filename);

    $sql= "insert into login (email,password,usertype) values('$email','$password','user')";
    echo $sql;
    $result = mysqli_query($con, $sql);
    $id="";
    $sql= "select max(id) as id from login";
    $result = mysqli_query($con, $sql);
    if($row =mysqli_fetch_array($result)){
        $id=$row[0];
    }
    $sql = "insert into registration (name,email,phoneno,address,city,userid,photo) values('$name','$email','$phoneno','$address','$city','$id','$filename')";
    echo $sql;
    $result = mysqli_query($con, $sql);
    
}

include "footer.php";
?>