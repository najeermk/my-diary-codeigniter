<?php
include "header.php";
?>
<div class="clear">
</div>
<!-- SUBHEADER
================================================== -->
<div id="subheader">
    <div class="row">
        <div class="twelve columns">
            <p class="left">
                CONTACT US
            </p>
            <p class="right">
                Get in touch today!
            </p>
        </div>
    </div>
</div>
<div class="hr">
</div>
<!-- CONTENT 
================================================== -->
<!-- <div class="row">
        // GOOGLE MAP IFRAME 
        <div class="twelve columns">
            <iframe class="gmap" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=disney+paris&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=39.371738,86.572266&amp;ie=UTF8&amp;hq=disney&amp;hnear=Paris,+%C3%8Ele-de-France,+France&amp;t=m&amp;fll=48.881877,2.535095&amp;fspn=0.512051,1.352692&amp;st=103241701817924407489&amp;rq=1&amp;ev=zo&amp;split=1&amp;ll=49.027964,2.772675&amp;spn=0.315159,0.585022&amp;z=10&amp;iwloc=D&amp;output=embed">
            </iframe>
        </div>
    </div> -->
<div class="row">
    <!-- CONTACT FORM -->
    <div class="twelve columns">
        <div class="wrapcontact">


            <form method="post" action="#" id="contactform">
                <div class="form">
                    <div class="six columns noleftmargin">
                        <label>Name</label>
                        <input type="text" name="name" class="smoothborder" placeholder="Your name *" />
                    </div>
                    <div class="six columns">
                        <label>E-mail address</label>
                        <input type="text" name="email" class="smoothborder" placeholder="Your e-mail address *" />
                    </div>
                    <div class="six columns noleftmargin">
                        <label>city</label>
                        <input type="text" name="city" class="smoothborder" placeholder="Your name *" />
                    </div>
                    <div class="six columns ">
                        <label>Date of birth</label>
                        <input type="date" name="date" class="smoothborder" placeholder="Your name *" />
                    </div>
                    <div class="six columns noleftmargin">
                        <label>Phone no 1</label>
                        <input type="text" name="phone1" class="smoothborder" placeholder="Your name *" />
                    </div>
                    <div class="six columns ">
                        <label>Phone no 2</label>
                        <input type="text" name="phone2" class="smoothborder" placeholder="Your name *" />
                    </div>
                    <label>Address</label>
                    <textarea name="address" class="smoothborder ctextarea" rows="14" placeholder="Address"></textarea>
                    <input type="submit" id="submit" name="submit" class="readmore" value="Submit">
                </div>
            </form>
        </div>
    </div>

</div>
<div class="hr">
</div>

<?php
include "footer.php";

include "database.php";

if (isset($_POST["submit"])) {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $city = $_POST["city"];
    $date = $_POST["date"];
    $phone1 = $_POST["phone1"];
    $phone2 = $_POST["phone2"];
    $address = $_POST["address"];

    $sql = "insert into contacts(name,address,city,email,phoneno1,phoneno2,date of birth) values('$name','$address','$city','$email','$phone1','$phone2','$date')";
    echo $sql;
    $result = mysqli_query($con, $sql);
}

?>