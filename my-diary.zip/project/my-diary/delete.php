<?php
include "header.php";
?>
<div class="clear">
</div>


<?php
include "database.php";

if (isset($_POST["delete"])) {
	$id=$_GET["id"];
	$sql= "delete from contacts where id=$id";
	$result=mysqli_query($con, $sql);
}


include "footer.php";
?>