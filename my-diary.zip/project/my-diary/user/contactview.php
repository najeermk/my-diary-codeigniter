<?php


include "header.php";

    include "database.php";
    $id =$_SESSION["id"];

    $sql = "select * from contacts where userid='$id'";
    echo $sql;
?>
<div class="clear">
</div>
<table width=100%>
    <tr>
        <th>id</th>
        <th>name</th>
        <th>address</th>
        <th>city</th>
        <th>email</th>
        <th>phone no1</th>
        <th>phone no2</th>
    </tr>
 <?php
    $result = mysqli_query($con, $sql);
    while ($row = mysqli_fetch_array($result)) {
        echo  "<tr><td>" . $row["id"];
        echo  "</td><td>" . $row["name"];
        echo  "</td><td>" . $row["address"];
        echo  "</td><td>" . $row["city"];
        echo  "</td><td>" . $row["email"];
        echo  "</td><td>" . $row["phoneno1"];
        echo  "</td><td>" . $row["phoneno2"];
        echo  "</td><td><a href='edit.php?id=$row[id]'>Edit</a></td>";
        echo "<td><a href='delete.php?id=$row[id]'>Delete</a></td></tr>";
    }
    ?>
</table>
<br>
<br><br><br>
<?php
include "footer.php";
?>