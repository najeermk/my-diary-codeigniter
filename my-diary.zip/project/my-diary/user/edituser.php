<?php

include "header.php";

?>
<div class="clear">
</div>


<?php
include "database.php";

$id = $_SESSION["id"];
$sql = "select * from registration where userid=$id";
echo $sql;
$result = mysqli_query($con, $sql);
while ($row = mysqli_fetch_array($result)) {
?>
    
<div class="row">
    <div class="twelve columns">
        <div class="wrapcontact">

        <form method="POST" action="#" id="contactform">
       
            <div class="twelve columns noleftmargin">
                        <label>Name</label>
                        <input type="text" name="name" class="smoothborder" value='<?php echo $row["name"]; ?>' />
                    </div>
                    <div class="twelve columns noleftmargin">
                        <label>E-mail address</label>
                        <input type="text" name="email" class="smoothborder" value='<?php echo $row["email"]; ?>' />
                    </div>
                 
                    <div class="twelve columns noleftmargin">
                        <label>Phone no</label>
                        <input type="text" name="phone" class="smoothborder" value='<?php echo $row["phoneno"]; ?>' />
                    </div>
                    <div class="twelve columns noleftmargin">
                        <label>City</label>
                        <input type="text" name="city" class="smoothborder" value='<?php echo $row["city"]; ?>' />
                    </div>
                   
                    
                    <div class="twelve columns noleftmargin">
                        <label>Address</label>
                        <textarea name="address" class="smoothborder ctextarea" rows="14" value='<?php echo $row["address"]; ?>'></textarea>
                        <input type="submit" name="update" id="submit" class="readmore" value="update">
                    </div>

            </form>
    </div>
</div>
</div>

<?php
}

if (isset($_POST["update"])) {
    //$id=$_POST["id"];
    $name=$_POST["name"];
    $address=$_POST["address"];
    $city=$_POST["city"];
    $email=$_POST["email"];
    $phoneno=$_POST["phone"];
    
    $sql= "update registration set name='$name', address='$address', city='$city', email='$email', phoneno='$phoneno' where userid='$id'";
    echo $sql;
    $result=mysqli_query($con, $sql);
    echo "updated";
    //header("location:index.php");
}

include "footer.php";
?>