<?php


include "header.php";

    include "database.php";
    $id =$_SESSION["id"];
   ?>

<div class="clear">
</div>

<div class="row">
    <div class="twelve columns">
        <div class="wrapcontact">
            <form method="post" action="#" id="contactform">
                <div class="form">

                    <div class="twelve columns noleftmargin">
                        <label>Search contacts</label>
                        <input type="text" name="name" class="smoothborder" />
                    </div>
                    <div>
                    	<input type="submit" name="search" value="search" class="readmore" id="submit">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>



   <?php

   if (isset($_POST["search"])) {
   		$name = $_POST["name"];
   		$sql= "select * from contacts where name like '%$name%'";
   		echo $sql;
   		$result=mysqli_query($con, $sql);
   		while ($row = mysqli_fetch_array($result)) {
   			echo "<table width=100% ><tr><td>".$row["id"];
   			echo  "</td><td>" . $row["name"];
        	echo  "</td><td>" . $row["address"];
        	echo  "</td><td>" . $row["city"];
        	echo  "</td><td>" . $row["email"];
        	echo  "</td><td>" . $row["phoneno1"];
        	echo  "</td><td>" . $row["phoneno2"];
        	echo "</td></tr></table>";
        }
   }


include "footer.php";
?>