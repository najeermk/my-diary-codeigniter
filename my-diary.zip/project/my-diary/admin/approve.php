<?php

include "header.php";

?>
<div class="clear">
</div>


<?php

include "database.php";

	$id=$_GET["id"];
	$sql = "update login set status='1' where id=$id";
	$result=mysqli_query($con, $sql);
	echo $sql;
	header("location:registerview.php");



include "footer.php";
?>