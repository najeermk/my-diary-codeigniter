<?php
include "header.php";

?>
<div class="clear">
</div>


<?php

include "database.php";

	$id=$_GET["id"];
	$sql = "delete from login where id=$id";
	$result=mysqli_query($con, $sql);
	echo $sql;
	header("location:registerview.php");



include "footer.php";
?>