<?php
include "header.php";
?>
<div class="clear">
</div>



<table width="100%">
<tr>
        
        <th>name</th>    
        <th>email</th>
        <th>phone no</th>
        <th>user id</th>
        <th>address</th>
        <th>city</th>
        <th>photo</th>
    </tr>
<?php

include "database.php";
$sql= "select * from registration";
$result = mysqli_query($con, $sql);
while ($row = mysqli_fetch_array($result)) {
    echo "<tr><td>".$row["userid"];
	echo "</td><td>".$row["name"];
	echo "</td><td>".$row["email"];
	echo "</td><td>".$row["phoneno"];
	echo "</td><td>".$row["userid"];
	echo "</td><td>".$row["address"];
	echo "</td><td>".$row["city"];
	echo "</td><td><img src='upload/".$row["photo"]."' width=100px>";
	echo  "</td><td><a href='approve.php?id=$row[userid]'>Approve</a></td>";
    echo "<td><a href='remove.php?id=$row[userid]'>Remove</a></td></tr>";
}
?>
</table>
<?php
include "footer.php";
?>