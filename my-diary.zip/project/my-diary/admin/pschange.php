<?php
include "header.php";
?>
<div class="clear">
</div>
<div class="row">
	<div class="twelve columns">
		<div class="wrapcontent">
		<form method="POST">
			<div>
				<label>current</label>
				<input type="password" name="old">
			</div>
			<div>
				<label>new</label>
				<input type="password" name="new">
			</div>
			<div>
				<label>confirm</label>
				<input type="password" name="confirm">
			</div>
			
			<input type="submit" name="submit" value="submit">
		</form>

		</div>
	</div>
</div>
	

<?php
include "database.php";

if (isset($_POST["submit"])) {
	$current= $_POST["old"];
	$new=$_POST["new"];
	$confirm=$_POST["confirm"];
	$sql= "select * from login where usertype='admin' and password='$current'";
	echo $sql;
	$result=mysqli_query($con, $sql);
	if ($row=mysqli_fetch_array($result)) {
		$pass=$row["password"];
		if ($new == $confirm) {
			$sql= "update login set password='$new' where usertype='admin'";
			echo $sql;
			$result =mysqli_query($con, $sql);
		}
		else{
			echo "password does not match";
		}
	}
	else{
		echo "incorrect password";
	}
}

include "footer.php";
?>